"""
La classe JoueurOrdinateur

Hérite de Joueur et contient une "intelligence artificielle" extrêmement rudimentaire.
"""

from random import randint
from jeu.joueur import Joueur


#### DÉBUT DÉFI JOUEUR ORDINATEUR ####

class JoueurOrdinateur(Joueur):
    def __init__(self, numero_joueur, des_initiaux, arene):
        super().__init__(numero_joueur, des_initiaux, arene)


    # Écrivez les 4 méthodes demandées.

    def decision_continuer(self):
        x = True
        if randint(1, 4) == 1:
            x = False
        return x


    def choisir_coordonnees(self):
        return super().piger_coordonnees()



    def choisir_angle(self):
        return super().piger_angle()



    def choisir_puissance(self):
        return super().piger_puissance()

#### FIN DÉFI JOUEUR ORDINATEUR ####
