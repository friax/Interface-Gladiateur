from interface.fenetre_principale import FenetrePrincipale

########################################
# Point d'entrée du TP4
########################################

fenetre_principale = FenetrePrincipale()
fenetre_principale.mainloop()
